package com.dailydose.lifehackes;

public class QuotsShowItems {
    String quotes;

    public QuotsShowItems(String quotes) {
        this.quotes = quotes;
    }

    public String getQuotes() {
        return quotes;
    }

    public void setQuotes(String quotes) {
        this.quotes = quotes;
    }
}
