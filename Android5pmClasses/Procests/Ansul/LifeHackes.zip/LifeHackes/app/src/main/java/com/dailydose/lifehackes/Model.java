package com.dailydose.lifehackes;

public class Model {

    String image;

    public Model() {
    }

    public Model(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
